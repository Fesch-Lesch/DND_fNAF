    </main>
    <footer class="footer">
        <p>&copy; <?= date('Y') ?> DnD System</p>
    </footer>
</body>
</html>